# VitalSphere Auto-Update System

## Overview

The VitalSphere Auto-Update system provides seamless, silent updates by downloading the latest `VitalSphere.exe` from GitHub, automatically closing the application, installing the update, and restarting.

## Features

- ✅ **Silent Installation** - Updates install without user interaction
- ✅ **Progress Tracking** - Real-time download progress with size information
- ✅ **Automatic Restart** - Application automatically restarts after installation
- ✅ **Version Comparison** - Intelligent version checking (1.0.0 vs 1.0.1 vs 1.1.0)
- ✅ **GitHub Integration** - Downloads directly from GitHub Release branch
- ✅ **Error Handling** - Comprehensive error handling and recovery
- ✅ **Changelog Display** - Shows what's new in each update
- ✅ **Manual & Automatic Modes** - User choice between manual steps or full auto-update

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     VitalSphere App                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────┐         ┌─────────────────┐          │
│  │  Renderer UI    │────────▶│   Preload.js    │          │
│  │                 │  IPC    │                 │          │
│  │ - Settings      │◀────────│ - API Exposure  │          │
│  │ - Notifications │         │ - Event Bridge  │          │
│  └─────────────────┘         └─────────────────┘          │
│         │                             │                     │
│         │                             │                     │
│         ▼                             ▼                     │
│  ┌─────────────────────────────────────────────┐          │
│  │           Main Process (main.js)            │          │
│  │                                             │          │
│  │  - IPC Handlers                            │          │
│  │  - Update Orchestration                    │          │
│  └──────────────┬──────────────────────────────┘          │
│                 │                                          │
│                 ▼                                          │
│  ┌─────────────────────────────────────────────┐          │
│  │     VitalSphereAutoUpdater Class           │          │
│  │       (auto-updater.js)                    │          │
│  │                                             │          │
│  │  - checkForUpdates()                       │          │
│  │  - downloadUpdate(progressCallback)        │          │
│  │  - installUpdate(silent)                   │          │
│  │  - performAutoUpdate(silent, progress)     │          │
│  └─────────────────────────────────────────────┘          │
│         │                                                  │
│         ▼                                                  │
│  ┌─────────────────────────────────────────────┐          │
│  │           GitHub Repository                 │          │
│  │  Release Branch                             │          │
│  │                                             │          │
│  │  - update.json (version info)              │          │
│  │  - VitalSphere.exe (installer)             │          │
│  └─────────────────────────────────────────────┘          │
└─────────────────────────────────────────────────────────────┘
```

## Files Structure

```
vitalsphere/
├── auto-updater.js          # Core auto-updater class
├── main.js                  # Electron main process (with IPC handlers)
├── preload.js               # IPC bridge to renderer
├── update.json              # Version info and changelog
├── update-manager.html      # UI for managing updates
├── update-examples.js       # Code examples and integration patterns
└── UPDATE_SYSTEM.md        # This file
```

## Setup

### 1. GitHub Repository Setup

Your GitHub repository must have a `Release` branch with these files:

```
Release/
├── update.json           # Version metadata
└── VitalSphere.exe      # Installer executable
```

#### update.json Format

```json
{
    "version": "1.0.1",
    "releaseDate": "2025-11-11",
    "releaseNotes": "Bug fixes and new features",
    "downloadUrl": "https://github.com/divyanshvitalblink/vitalsphere/raw/Release/VitalSphere.exe",
    "changelog": [
        "Added silent auto-update system",
        "Enhanced update download with progress tracking",
        "Improved installer integration"
    ],
    "critical": false,
    "minVersion": "1.0.0"
}
```

### 2. URLs Configuration

The auto-updater uses these URLs:

- **Update Check**: `https://raw.githubusercontent.com/divyanshvitalblink/vitalsphere/Release/update.json`
- **Download**: `https://github.com/divyanshvitalblink/vitalsphere/raw/Release/VitalSphere.exe`

These are configured in `auto-updater.js`:

```javascript
this.updateCheckUrl = 'https://raw.githubusercontent.com/divyanshvitalblink/vitalsphere/Release/update.json';
this.exeDownloadUrl = 'https://github.com/divyanshvitalblink/vitalsphere/raw/Release/VitalSphere.exe';
```

## Usage

### Method 1: Update Manager UI (Recommended for Users)

Open the Update Manager page:

```javascript
// From browser or any page
window.location.href = 'update-manager.html';
```

The Update Manager provides:
- Check for updates button
- Download progress with percentage and size
- Install & restart button
- Auto-update (all-in-one) button
- Silent installation toggle
- Changelog display

### Method 2: Programmatic API (For Developers)

#### Check for Updates

```javascript
const updateInfo = await window.electronAPI.vitalSphereCheckUpdate();

if (updateInfo.available) {
    console.log('Update available:', updateInfo.version);
    console.log('Release date:', updateInfo.releaseDate);
    console.log('Changelog:', updateInfo.changelog);
} else {
    console.log('No updates available');
}
```

#### Download Update with Progress

```javascript
// Listen for progress events
window.electronAPI.onUpdateDownloadProgress((data) => {
    console.log(`Download: ${data.percent}%`);
    console.log(`Downloaded: ${data.downloadedFormatted}`);
    console.log(`Total: ${data.totalFormatted}`);
});

// Start download
const result = await window.electronAPI.vitalSphereDownloadUpdate();

if (result.success) {
    console.log('Download complete:', result.path);
}
```

#### Install Update

```javascript
// Silent installation (no user interaction)
await window.electronAPI.vitalSphereInstallUpdate(true);

// OR Interactive installation (shows progress)
await window.electronAPI.vitalSphereInstallUpdate(false);

// App will quit and restart after installation
```

#### Full Auto-Update (All-in-One)

```javascript
// Check, download, and install in one call
const result = await window.electronAPI.vitalSphereAutoUpdate(true);

if (result.success) {
    console.log('Update completed');
    // App will restart
}
```

## API Reference

### Main Process (auto-updater.js)

#### `checkForUpdates()`

Checks GitHub for available updates.

**Returns**: `Promise<Object>`
```javascript
{
    available: true,
    version: "1.0.1",
    releaseDate: "2025-11-11",
    releaseNotes: "Bug fixes...",
    changelog: ["Feature 1", "Feature 2"],
    critical: false,
    downloadUrl: "https://..."
}
```

#### `downloadUpdate(progressCallback)`

Downloads the update file.

**Parameters**:
- `progressCallback(percent, downloaded, total)` - Called during download

**Returns**: `Promise<string>` - Path to downloaded file

#### `installUpdate(silent = true)`

Installs the downloaded update.

**Parameters**:
- `silent` (boolean) - If true, installs silently without user interaction

**Returns**: `Promise<void>`

**Note**: App will quit during installation

#### `performAutoUpdate(silent, progressCallback)`

Performs complete update: check → download → install.

**Parameters**:
- `silent` (boolean) - Silent installation mode
- `progressCallback(percent, downloaded, total)` - Progress updates

**Returns**: `Promise<boolean>` - True if update was performed

### Renderer Process (electronAPI)

All methods are exposed via `window.electronAPI`:

```javascript
// Check for updates
await window.electronAPI.vitalSphereCheckUpdate()

// Download update
await window.electronAPI.vitalSphereDownloadUpdate()

// Install update
await window.electronAPI.vitalSphereInstallUpdate(silent)

// Full auto-update
await window.electronAPI.vitalSphereAutoUpdate(silent)

// Cleanup temp files
await window.electronAPI.vitalSphereCleanupUpdate()

// Get app version
await window.electronAPI.getAppVersion()

// Listen for download progress
window.electronAPI.onUpdateDownloadProgress((data) => { ... })
```

## Integration Examples

### Example 1: Check on Startup

```javascript
document.addEventListener('DOMContentLoaded', async () => {
    const updateInfo = await window.electronAPI.vitalSphereCheckUpdate();
    
    if (updateInfo.available) {
        const notify = confirm(`Update available: ${updateInfo.version}\n\nInstall now?`);
        if (notify) {
            await window.electronAPI.vitalSphereAutoUpdate(true);
        }
    }
});
```

### Example 2: Periodic Checks

```javascript
// Check every 24 hours
setInterval(async () => {
    const updateInfo = await window.electronAPI.vitalSphereCheckUpdate();
    if (updateInfo.available) {
        showUpdateNotification(updateInfo);
    }
}, 24 * 60 * 60 * 1000);
```

### Example 3: Settings Menu Integration

```javascript
function addUpdateMenuItem() {
    const menuItem = {
        label: 'Check for Updates',
        click: async () => {
            await window.electronAPI.vitalSphereAutoUpdate(true);
        }
    };
    return menuItem;
}
```

### Example 4: Update Banner

```javascript
async function showUpdateBanner() {
    const updateInfo = await window.electronAPI.vitalSphereCheckUpdate();
    
    if (updateInfo.available) {
        const banner = document.createElement('div');
        banner.innerHTML = `
            <div class="update-banner">
                Version ${updateInfo.version} available!
                <button onclick="installUpdate()">Install Now</button>
            </div>
        `;
        document.body.appendChild(banner);
    }
}

async function installUpdate() {
    await window.electronAPI.vitalSphereAutoUpdate(true);
}
```

## Version Comparison Logic

The system uses semantic versioning (SemVer):

```javascript
compareVersions("1.0.1", "1.0.0") // Returns 1 (newer)
compareVersions("1.0.0", "1.0.1") // Returns -1 (older)
compareVersions("1.0.0", "1.0.0") // Returns 0 (equal)
```

Format: `MAJOR.MINOR.PATCH`

- **MAJOR**: Breaking changes
- **MINOR**: New features (backward compatible)
- **PATCH**: Bug fixes

## Deployment Workflow

### 1. Build New Version

```bash
npm run build:win
```

This creates `VitalSphere.exe` in the `dist/` folder.

### 2. Update version.json

Update the version number and changelog:

```json
{
    "version": "1.0.2",
    "releaseDate": "2025-11-12",
    "releaseNotes": "New features and improvements",
    "downloadUrl": "https://github.com/divyanshvitalblink/vitalsphere/raw/Release/VitalSphere.exe",
    "changelog": [
        "Added new feature X",
        "Fixed bug Y",
        "Improved performance"
    ],
    "critical": false,
    "minVersion": "1.0.0"
}
```

### 3. Push to GitHub Release Branch

```bash
git checkout Release
git add VitalSphere.exe update.json
git commit -m "Release v1.0.2"
git push origin Release
```

### 4. Verify Update is Live

```bash
# Check update.json is accessible
curl https://raw.githubusercontent.com/divyanshvitalblink/vitalsphere/Release/update.json

# Check exe is accessible
curl -I https://github.com/divyanshvitalblink/vitalsphere/raw/Release/VitalSphere.exe
```

## Troubleshooting

### Issue: Update check fails with network error

**Solution**: Verify GitHub URLs are accessible:
```bash
curl https://raw.githubusercontent.com/divyanshvitalblink/vitalsphere/Release/update.json
```

### Issue: Download fails or file is corrupted

**Solution**: 
1. Check file size in GitHub (should be > 1MB)
2. Verify download URL in update.json
3. Try downloading manually to test

### Issue: Installer doesn't run silently

**Solution**: 
1. Ensure using NSIS installer with `/S` flag support
2. Check installer arguments in `auto-updater.js`
3. Test installer manually: `VitalSphere.exe /S /D=C:\Path\To\Install`

### Issue: App doesn't restart after installation

**Solution**: 
1. Check if installer has auto-restart option
2. Verify installer is closing old process
3. Add post-install script to start app

### Issue: Version comparison incorrect

**Solution**: 
1. Use semantic versioning (x.y.z)
2. Don't use prefixes like "v1.0.0"
3. Test with `compareVersions()` function

## Security Considerations

1. **HTTPS Only**: Always use HTTPS URLs for update checks and downloads
2. **Verify File Size**: Check downloaded file size before installation
3. **Code Signing**: Sign VitalSphere.exe with certificate (future enhancement)
4. **Checksum Validation**: Add SHA256 checksum to update.json (future enhancement)

## Future Enhancements

- [ ] Add SHA256 checksum validation
- [ ] Support delta updates (patch files)
- [ ] Add rollback functionality
- [ ] Support multiple channels (stable, beta, dev)
- [ ] Add update scheduling (install on next restart)
- [ ] Implement A/B testing for updates

## Support

For issues or questions:
- GitHub Issues: https://github.com/divyanshvitalblink/vitalsphere/issues
- Documentation: Check update-examples.js for code samples

## License

See LICENSE.txt in the root directory.

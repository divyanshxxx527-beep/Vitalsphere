# VitalSphere Update System Workflow

## Overview
The VitalSphere update system automatically checks for and installs updates from your GitHub repository using a simple JSON-based approach.

## Version Configuration

### Current Configuration
- **package.json version**: `1.0.0` (Current app version)
- **update.json version**: `1.0.0` (Latest available version)
- **GitHub Branch**: `main`
- **Repository**: `https://github.com/divyanshvitalblink/vitalsphere`

## How It Works

### 1. Version Check
The app checks for updates by reading `update.json` from:
```
https://raw.githubusercontent.com/divyanshvitalblink/vitalsphere/main/update.json
```

### 2. Version Comparison
- App compares `update.json` version with the version in `package.json`
- If `update.json` version > `package.json` version → Update available
- If versions match → No update needed

### 3. Download & Install
When an update is available:
1. Downloads the new installer from the URL specified in `update.json`
2. Silently installs the update
3. Restarts the application

## When to Release an Update

### Step 1: Update Version Numbers
When you're ready to release a new version:

```json
// 1. Update package.json
{
    "version": "1.0.1",  // Increment version
    ...
}

// 2. Update update.json (must match package.json)
{
    "version": "1.0.1",  // Same as package.json
    "releaseDate": "2025-11-12",
    "releaseNotes": "What's new in this version",
    ...
}
```

### Step 2: Build the Application
```powershell
# Build the new installer
.\build-nsis-installer.bat
```

### Step 3: Upload to GitHub
```powershell
# 1. Commit the version changes
git add package.json update.json
git commit -m "Release v1.0.1"

# 2. Upload the new installer to GitHub
# Place VitalSphere.exe at the root of your repository
# Or update the downloadUrl in update.json to point to GitHub Releases

# 3. Push to main branch
git push origin main
```

### Step 4: Users Get the Update
- Users running v1.0.0 will automatically detect v1.0.1 is available
- Update will download and install automatically

## Testing the Update System

### Manual Test (In Browser Console)
```javascript
// Check if update is available
const updateInfo = await window.electronAPI.vitalSphereCheckUpdate();
console.log('Update available:', updateInfo.available);
console.log('Latest version:', updateInfo.version);

// Download and install update
if (updateInfo.available) {
    await window.electronAPI.vitalSphereAutoUpdate(true);
}
```

### Using Test Script
The app includes `test-update-system.js` for testing:
```javascript
// Load the test script in browser console
testUpdateSystem();  // Runs complete test
```

## Update Configuration Files

### 1. auto-updater.js
Main update logic - handles checking, downloading, and installing updates.
- Update check URL: Points to `update.json` on GitHub
- Download URL: Points to installer on GitHub

### 2. browser-script.js
Frontend update checking - displays notifications to users.
- Checks for updates on startup
- Shows update notifications

### 3. main.js
Electron main process integration:
- IPC handlers for update operations
- Progress tracking
- Install coordination

### 4. preload.js
Exposes update API to renderer:
- `vitalSphereCheckUpdate()`
- `vitalSphereDownloadUpdate()`
- `vitalSphereInstallUpdate()`
- `vitalSphereAutoUpdate()`

## Update.json Structure

```json
{
    "version": "1.0.0",           // Must be > current version for update
    "releaseDate": "2025-11-12",  // Release date
    "releaseNotes": "Brief description of update",
    "downloadUrl": "https://github.com/divyanshvitalblink/vitalsphere/raw/main/VitalSphere.exe",
    "changelog": [                // Detailed changes
        "Feature 1",
        "Fix 1",
        "Enhancement 1"
    ],
    "critical": false,            // If true, forces immediate update
    "minVersion": "1.0.0"        // Minimum version that can update
}
```

## Important URLs

All update URLs now point to the `main` branch:

| File | URL |
|------|-----|
| update.json | `https://raw.githubusercontent.com/divyanshvitalblink/vitalsphere/main/update.json` |
| Installer | `https://github.com/divyanshvitalblink/vitalsphere/raw/main/VitalSphere.exe` |

## Checklist for Releasing Updates

- [ ] Increment version in `package.json`
- [ ] Update version in `update.json` to match
- [ ] Update `releaseDate` in `update.json`
- [ ] Update `releaseNotes` and `changelog` in `update.json`
- [ ] Build new installer with `build-nsis-installer.bat`
- [ ] Upload new `VitalSphere.exe` to GitHub repository root
- [ ] Commit and push `package.json` and `update.json` to main branch
- [ ] Test update detection on older version

## Troubleshooting

### Update Not Detected
1. Check that `update.json` version > `package.json` version
2. Verify `update.json` is accessible at the GitHub URL
3. Check browser console for error messages
4. Clear app cache and restart

### Download Fails
1. Verify `VitalSphere.exe` exists at the specified `downloadUrl`
2. Check file size - should be > 1MB
3. Test URL in browser to ensure file downloads correctly

### Installation Fails
1. Check file permissions
2. Verify installer was built correctly
3. Check antivirus isn't blocking installation

## Version Matching Example

### Current State (No Update)
```
package.json: "1.0.0"
update.json:  "1.0.0"
Result: ✓ No update needed
```

### After Release (Update Available)
```
User has:        "1.0.0"
update.json has: "1.0.1"
Result: ⚡ Update available! v1.0.1
```

### After User Updates
```
package.json: "1.0.1" (user installed update)
update.json:  "1.0.1"
Result: ✓ No update needed
```

## Notes

- Keep `package.json` and `update.json` versions in sync when releasing
- Always test updates before pushing to production
- Consider using GitHub Releases for better version management
- The system supports silent background updates
- Critical updates can force immediate installation

/**
 * VitalSphere Auto-Update Example Script
 * 
 * This script demonstrates how to programmatically trigger
 * the VitalSphere auto-update system.
 * 
 * Usage in renderer process (browser-script.js or similar):
 * 
 * 1. Check for updates:
 *    const updateInfo = await window.electronAPI.vitalSphereCheckUpdate();
 *    if (updateInfo.available) {
 *      console.log('Update available:', updateInfo.version);
 *    }
 * 
 * 2. Download update:
 *    const result = await window.electronAPI.vitalSphereDownloadUpdate();
 *    if (result.success) {
 *      console.log('Download complete');
 *    }
 * 
 * 3. Install update:
 *    await window.electronAPI.vitalSphereInstallUpdate(true); // true = silent
 * 
 * 4. Or do everything at once:
 *    await window.electronAPI.vitalSphereAutoUpdate(true);
 * 
 * 5. Listen for download progress:
 *    window.electronAPI.onUpdateDownloadProgress((data) => {
 *      console.log(`Download: ${data.percent}%`);
 *    });
 */

// Example 1: Silent auto-update on app startup (background check)
async function checkAndUpdateOnStartup() {
    try {
        console.log('[Auto-Update] Checking for updates on startup...');

        const updateInfo = await window.electronAPI.vitalSphereCheckUpdate();

        if (updateInfo.available) {
            console.log('[Auto-Update] Update available:', updateInfo.version);

            // Show a notification to the user
            if (window.Notification && Notification.permission === 'granted') {
                new Notification('VitalSphere Update Available', {
                    body: `Version ${updateInfo.version} is ready to download`,
                    icon: 'assets/icon.png'
                });
            }

            // Optionally auto-download in background
            // Uncomment to enable automatic background download:
            // const result = await window.electronAPI.vitalSphereDownloadUpdate();
            // if (result.success) {
            //     console.log('[Auto-Update] Update downloaded, ready to install');
            // }
        } else {
            console.log('[Auto-Update] No updates available');
        }
    } catch (error) {
        console.error('[Auto-Update] Startup check failed:', error);
    }
}

// Example 2: Show update notification with user prompt
async function promptUserForUpdate() {
    try {
        const updateInfo = await window.electronAPI.vitalSphereCheckUpdate();

        if (updateInfo.available) {
            const userWantsUpdate = confirm(
                `VitalSphere ${updateInfo.version} is available!\n\n` +
                `Release Date: ${updateInfo.releaseDate}\n` +
                `${updateInfo.releaseNotes}\n\n` +
                `Would you like to download and install it now?`
            );

            if (userWantsUpdate) {
                // Perform silent auto-update
                await window.electronAPI.vitalSphereAutoUpdate(true);
                // App will restart after installation
            }
        } else {
            alert('You are already running the latest version of VitalSphere!');
        }
    } catch (error) {
        console.error('[Auto-Update] Update prompt failed:', error);
        alert('Failed to check for updates: ' + error.message);
    }
}

// Example 3: Scheduled update check (every 24 hours)
function schedulePeriodicUpdateCheck() {
    const CHECK_INTERVAL = 24 * 60 * 60 * 1000; // 24 hours

    console.log('[Auto-Update] Scheduling periodic update checks');

    // Check immediately
    checkAndUpdateOnStartup();

    // Then check every 24 hours
    setInterval(() => {
        console.log('[Auto-Update] Performing scheduled update check');
        checkAndUpdateOnStartup();
    }, CHECK_INTERVAL);
}

// Example 4: Update with progress tracking
async function updateWithProgressUI() {
    try {
        // Check for updates first
        const updateInfo = await window.electronAPI.vitalSphereCheckUpdate();

        if (!updateInfo.available) {
            console.log('No updates available');
            return;
        }

        console.log('Update available:', updateInfo.version);

        // Create progress UI
        const progressDiv = document.createElement('div');
        progressDiv.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            z-index: 10000;
            min-width: 300px;
        `;
        progressDiv.innerHTML = `
            <h3 style="margin: 0 0 10px 0;">Downloading Update...</h3>
            <div style="background: #e0e0e0; height: 20px; border-radius: 10px; overflow: hidden;">
                <div id="progress-bar" style="background: #4ade80; height: 100%; width: 0%; transition: width 0.3s;"></div>
            </div>
            <p id="progress-text" style="margin: 10px 0 0 0; font-size: 0.9rem;">Starting download...</p>
        `;
        document.body.appendChild(progressDiv);

        // Listen for progress
        window.electronAPI.onUpdateDownloadProgress((data) => {
            const progressBar = document.getElementById('progress-bar');
            const progressText = document.getElementById('progress-text');

            if (progressBar) progressBar.style.width = data.percent + '%';
            if (progressText) progressText.textContent =
                `${data.percent}% (${data.downloadedFormatted} / ${data.totalFormatted})`;
        });

        // Download update
        const downloadResult = await window.electronAPI.vitalSphereDownloadUpdate();

        if (downloadResult.success) {
            progressDiv.innerHTML = `
                <h3 style="margin: 0 0 10px 0; color: #22c55e;">✓ Download Complete!</h3>
                <p>Installing update and restarting...</p>
            `;

            // Wait a moment then install
            await new Promise(resolve => setTimeout(resolve, 1000));
            await window.electronAPI.vitalSphereInstallUpdate(true);
        }
    } catch (error) {
        console.error('[Auto-Update] Update with progress failed:', error);
        alert('Update failed: ' + error.message);
    }
}

// Example 5: Add update button to UI
function addUpdateButtonToUI() {
    const button = document.createElement('button');
    button.textContent = '🔄 Check for Updates';
    button.style.cssText = `
        position: fixed;
        top: 10px;
        right: 10px;
        padding: 10px 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: 600;
        z-index: 10000;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    `;

    button.addEventListener('click', promptUserForUpdate);
    document.body.appendChild(button);
}

// Example 6: Critical update check (force update if critical)
async function checkForCriticalUpdates() {
    try {
        const updateInfo = await window.electronAPI.vitalSphereCheckUpdate();

        if (updateInfo.available && updateInfo.critical) {
            alert(
                'CRITICAL UPDATE REQUIRED\n\n' +
                `Version ${updateInfo.version} contains critical security or stability fixes.\n\n` +
                'The update will be installed automatically.'
            );

            // Force silent update
            await window.electronAPI.vitalSphereAutoUpdate(true);
            // App will restart
        }
    } catch (error) {
        console.error('[Auto-Update] Critical update check failed:', error);
    }
}

// ============================================
// Integration Examples
// ============================================

// Add to your app initialization:
document.addEventListener('DOMContentLoaded', () => {
    // Option 1: Silent background check on startup
    // checkAndUpdateOnStartup();

    // Option 2: Schedule periodic checks
    // schedulePeriodicUpdateCheck();

    // Option 3: Add update button to UI
    // addUpdateButtonToUI();

    // Option 4: Check for critical updates
    // checkForCriticalUpdates();
});

// You can also trigger updates from menu or settings:
// Example menu item click handler:
async function onUpdateMenuItemClick() {
    await promptUserForUpdate();
}

// Example settings button:
async function onSettingsUpdateButtonClick() {
    // Open update manager page
    window.location.href = 'update-manager.html';
}

// Export functions for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        checkAndUpdateOnStartup,
        promptUserForUpdate,
        schedulePeriodicUpdateCheck,
        updateWithProgressUI,
        addUpdateButtonToUI,
        checkForCriticalUpdates
    };
}
